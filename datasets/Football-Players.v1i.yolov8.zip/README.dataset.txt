# Football-Players > 2024-05-22 3:31pm
https://universe.roboflow.com/redbean-xxypc/football-players-pl4fg

Provided by a Roboflow user
License: CC BY 4.0

